package constants;

public class Strings {

    final static private String APP_NAME = "COLLEGE MANAGEMENT SYSTEM";

    public static String getAPP_NAME() {
        return APP_NAME;
    }
}
